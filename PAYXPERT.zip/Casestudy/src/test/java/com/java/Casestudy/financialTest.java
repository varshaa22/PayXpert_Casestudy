package com.java.Casestudy;

import static org.junit.Assert.*;

import org.junit.Test;

public class financialTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
