package com.java.Casestudy.model;

public enum RecordType {
    INCOME, EXPENSE, TAXPAYMENT;
}
