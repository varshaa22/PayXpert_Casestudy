package com.java.Casestudy.model;

public enum Gender {
	MALE,FEMALE,OTHER
}
