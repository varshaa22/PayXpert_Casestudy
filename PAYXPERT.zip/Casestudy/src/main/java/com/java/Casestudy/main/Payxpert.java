package com.java.Casestudy.main;

import java.sql.SQLException;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.google.protobuf.TextFormat.ParseException;
import com.java.Casestudy.Dao.EmployeeDao;
import com.java.Casestudy.Dao.EmployeeDaoImpl;
import com.java.Casestudy.Dao.ParollDao;
import com.java.Casestudy.Dao.ParollDaoImpl;
import com.java.Casestudy.model.Employee;
import com.java.Casestudy.model.Financial;
import com.java.Casestudy.model.Gender;
import com.java.Casestudy.model.LeaveDetails;
import com.java.Casestudy.model.Maritalstatus;
import com.java.Casestudy.model.Payroll;
import com.java.Casestudy.model.RecordType;
import com.java.Casestudy.Dao.LeaveDetailsDao;
import com.java.Casestudy.Dao.LeaveDetailsDaoImpl;
import com.java.Casestudy.Dao.FinancialDao;
import com.java.Casestudy.Dao.FinancialDaoImpl;


public class Payxpert {
	static Scanner sc=new Scanner(System.in);
	static EmployeeDao employeeDao=new EmployeeDaoImpl();
	static ParollDao payrollDao=new ParollDaoImpl();
	static LeaveDetailsDao leaveDao=new LeaveDetailsDaoImpl();
	static FinancialDao financialDao=new FinancialDaoImpl();
	public static void employeeShow() throws ClassNotFoundException, SQLException {
		List<Employee> employeeList = employeeDao.showEmployDao();
		for (Employee employee : employeeList) {
			System.out.println(employee);
		}
	}
	public static void searchByEmpId() throws ClassNotFoundException, SQLException {
		int empId;
		System.out.println("Enter Employee Id  ");
		empId = sc.nextInt();
		Employee employee = employeeDao.searchByEmpId(empId);
		if (employee!=null) {
			System.out.println(employee);
		} else {
			System.out.println("*** Employee Record Not Found ***");
		}
	}
	public static void addEmployDao() throws ClassNotFoundException, SQLException, java.text.ParseException {
	    Employee employee = new Employee();    
	    System.out.println("Enter First Name: ");
	    employee.setFirstName(sc.next()); 
	    System.out.println("Enter Last Name: ");
	    employee.setLastName(sc.next()); 
	    System.out.println("Enter Gender (Male/Female/Other): ");
	    String genderStr = sc.next();
	    try {
	        employee.setGender(Gender.valueOf(genderStr.toUpperCase())); 
	    } catch (IllegalArgumentException e) {
	        System.out.println("Invalid gender. Please enter Male, Female, or Other.");
	        return;
	    }
	    System.out.println("Enter Date of Birth (yyyy-MM-dd): ");
	    String dobStr = sc.next();
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	    Date dob = sdf.parse(dobStr);
	    employee.setDob(new java.sql.Date(dob.getTime()));
	    System.out.println("Enter Marital Status (Single/Married/Other): ");
	    String maritalStatusStr = sc.next();
	    try {
	        employee.setMaritalStatus(Maritalstatus.valueOf(maritalStatusStr)); 
	    } catch (IllegalArgumentException e) {
	        System.out.println("Invalid marital status. Please enter Single, Married, or Other.");
	        return;
	    }
	    System.out.println("Enter City: ");
	    employee.setCity(sc.next());
	    System.out.println("Enter State: ");
	    employee.setState(sc.next());
	    
	    System.out.println("Enter Email: ");
	    employee.setEmail(sc.next());
	    System.out.println("Enter Mobile No: ");
	    employee.setMobileNo(sc.next());
	    System.out.println("Enter Date of Joining (yyyy-MM-dd): ");
	    String dojStr = sc.next();
	    Date dateOfJoin = sdf.parse(dojStr);
	    employee.setDateOfJoin(new java.sql.Date(dateOfJoin.getTime()));
	    System.out.println("Enter Position: ");
	    employee.setPosition(sc.next());
	    System.out.println("Enter Leave Available: ");
	    employee.setLeaveAvail(sc.nextInt());
	    String result = employeeDao.addEmployDao(employee);
	    System.out.println(result);
	}

	public static void searchByName() throws SQLException, ClassNotFoundException {
        System.out.println("Enter First Name : ");
        String fullName = sc.next();
        List<Employee> employees = employeeDao.searchByName(fullName);  
            for (Employee emp : employees) {
                System.out.println(emp);
            }
    }
	
	
	public static void applyLeave() throws ParseException {
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	    sdf.setLenient(false); 
	    LeaveDetails leave = new LeaveDetails();

	    try {
	        System.out.println("Enter Employee ID: ");
	        if (!sc.hasNextInt()) { 
	            System.out.println("Invalid Employee ID. Please enter a valid number.");
	            sc.next(); 
	            return;
	        }
	        leave.setEmpId(sc.nextInt());
	        sc.nextLine(); 

	        System.out.println("Enter Leave Start Date (yyyy-MM-dd): ");
	        String startDateInput = sc.nextLine();
	        Date dt1 = sdf.parse(startDateInput);
	        java.sql.Date sqlDate1 = new java.sql.Date(dt1.getTime());
	        leave.setLeaveStartDate(sqlDate1);

	        System.out.println("Enter Leave End Date (yyyy-MM-dd): ");
	        String endDateInput = sc.nextLine();
	        Date dt2 = sdf.parse(endDateInput);
	        java.sql.Date sqlDate2 = new java.sql.Date(dt2.getTime());
	        leave.setLeaveEndDate(sqlDate2);

	        if (!sqlDate2.after(sqlDate1)) {
	            System.out.println("Error: Leave End Date must be after Leave Start Date.");
	            return;
	        }
	        long days = (sqlDate2.getTime() - sqlDate1.getTime()) / (1000 * 60 * 60 * 24);
	        leave.setLop(calculateLop(days)); 
	        LeaveDetailsDao leaveDao=new LeaveDetailsDaoImpl(); 
	        leaveDao.applyLeave(leave);

	        System.out.println("Leave successfully applied for Employee ID: " + leave.getEmpId());
	        System.out.println("Leave Start Date: " + sqlDate1);
	        System.out.println("Leave End Date: " + sqlDate2);
	    } catch (SQLException e) {
	        System.out.println("Database error: " + e.getMessage());
	    } catch (Exception e) {
	        System.out.println("An unexpected error occurred: " + e.getMessage());
	    }
	}
	private static double calculateLop(long days) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public static void searchByleaveId() throws SQLException, ClassNotFoundException {
        int leaveId;
        System.out.print("Enter Employee Id: ");
        try {
            leaveId = sc.nextInt();  
        } catch (Exception e) {
            System.out.println("Invalid input. Please enter a valid integer.");
            return;  
        }
        LeaveDetails leave = leaveDao.searchLeaveById(leaveId);
        if (leave != null) {
            System.out.println(leave);
        } else {
            System.out.println("*** Employee Record Not Found ***");
        }
    }
	
	public static void getEmployeeByLeaveId() throws SQLException, ClassNotFoundException {
	    System.out.print("Enter Leave ID: ");
	    int leaveID = sc.nextInt();  
	    Employee employee = leaveDao.getEmployeeByLeaveId(leaveID);
	    if (employee != null) {
	        System.out.println("Employee ID: " + employee.getEmpId());
	        System.out.println("First Name: " + employee.getFirstName());
	        System.out.println("Last Name: " + employee.getLastName());
	        System.out.println("Email: " + employee.getEmail());
	    } else {
	        System.out.println("No employee found with the given leave ID.");
	    }
	}
	
    public static void addFinancialRecord() throws SQLException, ClassNotFoundException {
        Financial financial = new Financial(); 

        try {
            // Prompt user for Employee ID
            System.out.print("Enter Employee ID: ");
            financial.setEmployeeID(sc.nextInt());

            // Prompt user for Record Date (Date)
            System.out.print("Enter Record Date (YYYY-MM-DD): ");
            String recordDateStr = sc.next();
            java.sql.Date recordDate = java.sql.Date.valueOf(recordDateStr);
            financial.setRecordDate(recordDate);
            System.out.print("Enter Description: ");
            financial.setDescription(sc.next());
            System.out.print("Enter Amount: ");
            financial.setAmount(sc.nextDouble());
            System.out.print("Enter Record Type (INCOME/EXPENSE/TAXPAYMENT): ");
            String recordTypeStr = sc.next();
            try {
                financial.setRecordType(RecordType.valueOf(recordTypeStr.toUpperCase()));
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid record type. Please enter one of the following: INCOME, EXPENSE, TAXPAYMENT.");
                return;
            }
            boolean result = financialDao.addFinancialRecord(financial);
            if (result) {
                System.out.println("Financial record added successfully!");
            } else {
                System.out.println("Failed to add financial record.");
            }
        } catch (SQLException | ClassNotFoundException e) {
            System.out.println("Error occurred while adding financial record: " + e.getMessage());
        }
    }
	
	
	public static void addPayroll() throws SQLException, ClassNotFoundException {
	    try {
	        System.out.print("Enter Employee ID: ");
	        int empId = sc.nextInt();  
	        System.out.print("Enter Salary Date (YYYY-MM-DD): ");
	        String salaryDateStr = sc.next();  
	        java.sql.Date salaryDate = null;
	        try {
	            salaryDate = java.sql.Date.valueOf(salaryDateStr);  
	        } catch (IllegalArgumentException e) {
	            System.out.println("Invalid date format. Please use the format YYYY-MM-DD.");
	            return;  
	        }

	        System.out.print("Enter Salary: ");
	        double salary = sc.nextDouble();  
	        System.out.print("Enter HRA: ");
	        double hra = sc.nextDouble(); 
	        System.out.print("Enter DA: ");
	        double da = sc.nextDouble();  
	        System.out.print("Enter TA: ");
	        double ta = sc.nextDouble();  
	        System.out.print("Enter Tax: ");
	        double tax = sc.nextDouble(); 
	        System.out.print("Enter PF: ");
	        double pf = sc.nextDouble();  
	        Payroll payroll = new Payroll();
	        payroll.setEmpId(empId);
	        payroll.setSalaryDate(salaryDate);
	        payroll.setSalary(salary);
	        payroll.setHra(hra);
	        payroll.setDa(da);
	        payroll.setTa(ta);
	        payroll.setTax(tax);
	        payroll.setPf(pf);
	        ParollDaoImpl payrollDao = new ParollDaoImpl();
	        payrollDao.addPayRoll(payroll);
	        System.out.println("Payroll record inserted successfully for Employee ID: " + empId);
	    } catch (SQLException e) {
	        System.out.println("Database error: " + e.getMessage());
	    } catch (Exception e) {
	        System.out.println("An unexpected error occurred: " + e.getMessage());
	    }
	}
	
	
	public static void getPayrollByEmpIdAndSalDate() throws SQLException, ClassNotFoundException {
	    System.out.print("Enter Employee ID: ");
	    int empId = sc.nextInt();  
	    System.out.print("Enter Salary Date (YYYY-MM-DD): ");
	    String salaryDateStr = sc.next();  
	    LocalDate salaryDate = LocalDate.parse(salaryDateStr);  
	    ParollDaoImpl payrollDao = new ParollDaoImpl();
	    Payroll payroll = payrollDao.getPayrollByEmpIdAndSalDate(empId, salaryDate);
	    if (payroll != null) {
	        System.out.println("Payroll Details for Employee ID: " + empId + " on Salary Date: " + salaryDate);
	        System.out.println("Payroll ID: " + payroll.getPayrollId());
	        System.out.println("Employee ID: " + payroll.getEmpId());
	        System.out.println("Salary: " + payroll.getSalary());
	        System.out.println("HRA: " + payroll.getHra());
	        System.out.println("DA: " + payroll.getDa());
	        System.out.println("TA: " + payroll.getTa());
	        System.out.println("Tax: " + payroll.getTax());
	        System.out.println("PF: " + payroll.getPf());
	        Employee employee = payroll.getEmployee();
	        System.out.println("Employee Name: " + employee.getFirstName() + " " + employee.getLastName());
	        System.out.println("Employee Email: " + employee.getEmail());
	    } else {
	        System.out.println("No payroll found for the given Employee ID and Salary Date.");
	    }
	}
	
	
	public static void viewFinancialRecord() throws SQLException, ClassNotFoundException {
        System.out.println("Enter Record ID to view: ");
        int recordId = sc.nextInt();
        Financial financial = financialDao.infoByRecordId(recordId);
        if (financial != null) {
            System.out.println("Financial Record Details:");
            System.out.println("Employee ID: " + financial.getEmployeeID());
            System.out.println("Record Date: " + financial.getRecordDate());
            System.out.println("Description: " + financial.getDescription());
            System.out.println("Amount: " + financial.getAmount());
            System.out.println("Record Type: " + financial.getRecordType());
        } else {
            System.out.println("No financial record found for Record ID: " + recordId);
        }
    }
	
	
	public static void viewAllFinancialRecords() throws SQLException, ClassNotFoundException {
        List<Financial> financialRecords = financialDao.getAllEmployeeFinacialRecord();

        if (financialRecords != null && !financialRecords.isEmpty()) {
            System.out.println("Employee Financial Records:");
            for (Financial financial : financialRecords) {
                System.out.println("Employee ID: " + financial.getEmployeeID());
                System.out.println("Record Date: " + financial.getRecordDate());
                System.out.println("Description: " + financial.getDescription());
                System.out.println("Amount: " + financial.getAmount());
                System.out.println("Record Type: " + financial.getRecordType());
            }
        } else {
            System.out.println("No financial records found.");
        }
    }
	
	
	public static void getEmployeeFinancialInfo() throws ClassNotFoundException, SQLException {
        int empId;
        System.out.println("Enter Employee Id to get financial information: ");
        empId = sc.nextInt();
        List<Financial> financialRecords = financialDao.employeeFinacialInfo(empId);
        if (financialRecords != null && !financialRecords.isEmpty()) {
            System.out.println("Financial Records for Employee ID: " + empId);
            for (Financial record : financialRecords) {
                System.out.println(record);
            }
        } else {
            System.out.println("No financial records found for Employee ID: " + empId);
        }
    }
	
	
	public static void viewLastThreeMonthsPaySlips() throws SQLException, ClassNotFoundException {
	    System.out.println("Enter Employee ID: ");
	    int employeeId = sc.nextInt();
	    List<Financial> payslips = financialDao.getLastThreeMonthsPaySlips(employeeId);
	    if (!payslips.isEmpty()) {
	        for (Financial record : payslips) {
	            System.out.println(record);  
	        }
	    } else {
	        System.out.println("No pay slips found for the last 3 months for Employee ID: " + employeeId);
	    }
	}
	
	private static void  getEmployeeFinancialHistory() throws SQLException, ClassNotFoundException {
        System.out.println("Enter Employee ID: ");
        int employeeId = sc.nextInt();
        List<Financial> financialHistory = financialDao.getEmployeeFinancialHistory(employeeId);

        if (!financialHistory.isEmpty()) {
            System.out.println("\nEmployee Financial History:");
            for (Financial record : financialHistory) {
                System.out.println(record);
            }
        } else {
            System.out.println("No financial records found for Employee ID: " + employeeId);
        }
    }
	
	public static void showEmployeesWithoutPayroll() {
        try {
            System.out.println("Employees whose payroll has not started:");
            List<Employee> employees = financialDao.getEmployeesWithoutPayroll();
            //if (!employees.isEmpty()) {
                for (Employee emp : employees) {
                    displayEmployeeInfo(emp);
                }
            //} else {
               // System.out.println("All employees have started payroll.");
            //}
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("Error occurred while fetching employees without payroll.");
            e.printStackTrace();
        }
    }

    public static void displayEmployeeInfo(Employee employee) {
        System.out.println("EmpId: " + employee.getEmpId() + ", Name: " + employee.getFirstName() + " " + employee.getLastName() + ", Position: " + employee.getPosition());
    }

	
	public static void main(String[] args) throws ClassNotFoundException, SQLException, java.text.ParseException, ParseException {
		int choice;
		while(true){
			System.out.println("1. Show Employee");
			System.out.println("2.Search By Employee Id");
			System.out.println("3.Add Employee");
			System.out.println("4.Search By EmployeeName");
			System.out.println("5.Apply Leave");
			System.out.println("6.Search By Leave Id");
			System.out.println("7.Get Employeee By LeaveId");
			System.out.println("8.Add Payroll");
			System.out.println("9.Get Payroll by Employee ID and Salary Date");
			System.out.println("10.GetPayrollByEmpIdAndSalDate");
			System.out.println("11.ViewFinancialRecord");
			System.out.println("12.viewAllFinancialRecords");
			System.out.println("13.GetEmployeeFinancialInfo");
			System.out.println("14.ViewLastThreeMonthsPaySlips");
			System.out.println("15.Get Employee History");
			System.out.println("16.Employees Without Payroll");
			System.out.println("Enter Your Choice : ");
			
			
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				employeeShow();
			case 2:
				searchByEmpId();
			case 3:
				 addEmployDao();
				    break;
			case 4:
				searchByName();
				break;
			case 5:
				applyLeave();
			case 6:
				searchByleaveId();
			case 7:
				getEmployeeByLeaveId();
			case 8:
				addPayroll();
			case 9:
				getPayrollByEmpIdAndSalDate();
			case 10:
				getPayrollByEmpIdAndSalDate();
			case 11:
				viewFinancialRecord();
			case 12:
				viewAllFinancialRecords();
			case 13:
				getEmployeeFinancialInfo();
			case 14:
				viewLastThreeMonthsPaySlips(); 
			case 15:
				 getEmployeeFinancialHistory();
			case 16:
				showEmployeesWithoutPayroll();
				
			}
		}
	}
	
	
}
