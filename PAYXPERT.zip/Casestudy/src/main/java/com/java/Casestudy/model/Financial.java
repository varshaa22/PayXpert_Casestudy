package com.java.Casestudy.model;

import java.sql.Date;

public class Financial {
	private int RecordID; 
    private int EmployeeID; 
    private Date RecordDate;
    private String Description; 
    private double Amount;
    private RecordType RecordType;
	public int getRecordID() {
		return RecordID;
	}
	public void setRecordID(int recordID) {
		RecordID = recordID;
	}
	public int getEmployeeID() {
		return EmployeeID;
	}
	public void setEmployeeID(int employeeID) {
		EmployeeID = employeeID;
	}
	public Date getRecordDate() {
		return RecordDate;
	}
	public void setRecordDate(Date recordDate) {
		RecordDate = recordDate;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public double getAmount() {
		return Amount;
	}
	public void setAmount(double amount) {
		Amount = amount;
	}
	public RecordType getRecordType() {
		return RecordType;
	}
	public void setRecordType(RecordType recordType) {
		RecordType = recordType;
	}
	@Override
	public String toString() {
		return "Financial [RecordID=" + RecordID + ", EmployeeID=" + EmployeeID + ", RecordDate=" + RecordDate
				+ ", Description=" + Description + ", Amount=" + Amount + ", RecordType=" + RecordType + "]";
	}
	public Financial() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Financial(int recordID, int employeeID, Date recordDate, String description, double amount,
			RecordType recordType) {
		super();
		RecordID = recordID;
		EmployeeID = employeeID;
		RecordDate = recordDate;
		Description = description;
		Amount = amount;
		RecordType = recordType;
	}
    
    
}
	