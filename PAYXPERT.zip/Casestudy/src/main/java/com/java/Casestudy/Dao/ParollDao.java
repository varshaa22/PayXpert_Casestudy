package com.java.Casestudy.Dao;

import java.sql.SQLException;
import java.time.LocalDate;
import com.java.Casestudy.model.Payroll;

public interface ParollDao {
	public void addPayRoll(Payroll payroll) throws ClassNotFoundException, SQLException;
	public Payroll getPayrollByEmpIdAndSalDate(int employeeId, LocalDate salDate) throws SQLException, ClassNotFoundException ;
	

}
