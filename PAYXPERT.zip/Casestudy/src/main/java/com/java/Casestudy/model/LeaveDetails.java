package com.java.Casestudy.model;

import java.sql.Date;

public class LeaveDetails {
	private int LeaveId;    
	private int EmpId; 
    private Date LeaveStartDate; 
    private Date LeaveEndDate;
    private double Lop;
	public int getLeaveId() {
		return LeaveId;
	}
	public void setLeaveId(int leaveId) {
		LeaveId = leaveId;
	}
	public int getEmpId() {
		return EmpId;
	}
	public void setEmpId(int empId) {
		EmpId = empId;
	}
	public Date getLeaveStartDate() {
		return LeaveStartDate;
	}
	public void setLeaveStartDate(Date leaveStartDate) {
		LeaveStartDate = leaveStartDate;
	}
	public Date getLeaveEndDate() {
		return LeaveEndDate;
	}
	public void setLeaveEndDate(Date leaveEndDate) {
		LeaveEndDate = leaveEndDate;
	}
	public double getLop() {
		return Lop;
	}
	public void setLop(double lop) {
		Lop = lop;
	}
	@Override
	public String toString() {
		return "LeaveDetails [LeaveId=" + LeaveId + ", EmpId=" + EmpId + ", LeaveStartDate=" + LeaveStartDate
				+ ", LeaveEndDate=" + LeaveEndDate + ", Lop=" + Lop + "]";
	}
	public LeaveDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LeaveDetails(int leaveId, int empId, Date leaveStartDate, Date leaveEndDate, double lop) {
		super();
		LeaveId = leaveId;
		EmpId = empId;
		LeaveStartDate = leaveStartDate;
		LeaveEndDate = leaveEndDate;
		Lop = lop;
	}
    

}
