package com.java.Casestudy.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.Casestudy.model.Employee;
import com.java.Casestudy.model.Gender;
import com.java.Casestudy.model.Maritalstatus;
import com.java.Casestudy.util.ConnectionHelper;

public class EmployeeDaoImpl implements EmployeeDao{
	Connection connection;
	PreparedStatement pst;

	@Override
	public List<Employee> showEmployDao() throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
	    String cmd = "SELECT * FROM Employee";
	    pst = connection.prepareStatement(cmd);
	    ResultSet rs = pst.executeQuery();
	    List<Employee> employeeList = new ArrayList<>();
	    Employee employee = null;
	    while (rs.next()) {
	        employee = new Employee();
	        employee.setEmpId(rs.getInt("EmpId"));            // Correct column name
	        employee.setFirstName(rs.getString("FirstName")); // Correct column name
	        employee.setLastName(rs.getString("LastName"));
	        employee.setGender(Gender.valueOf(rs.getString("Gender")));
	        employee.setDob(rs.getDate("Dob"));
	        employee.setMaritalStatus(Maritalstatus.valueOf(rs.getString("MaritalStatus")));
	        employee.setCity(rs.getString("City"));
	        employee.setState(rs.getString("State"));
	        employee.setEmail(rs.getString("Email"));
	        employee.setMobileNo(rs.getString("MobileNo"));
	        employee.setDateOfJoin(rs.getDate("DateOfJoin"));
	        employee.setPosition(rs.getString("Position"));
	        employee.setLeaveAvail(rs.getInt("LeaveAvail"));
	        employeeList.add(employee);
		}
		// TODO Auto-generated method stub
		return employeeList;
	}

	@Override
	public Employee searchByEmpId(int empId) throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		String cmd = "select * from Employee WHERE EmpId = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, empId);
		ResultSet rs = pst.executeQuery();
		Employee employee = null;
		while(rs.next()) {
			employee = new Employee();
			employee.setEmpId(rs.getInt("EmpId"));
			employee.setFirstName(rs.getString("FirstName"));
			employee.setLastName(rs.getString("LastName"));
			employee.setGender(Gender.valueOf(rs.getString("gender")));
			employee.setDob(rs.getDate("Dob"));
			employee.setMaritalStatus(Maritalstatus.valueOf(rs.getString("Maritalstatus")));
			employee.setCity(rs.getString("City"));
			employee.setState(rs.getString("State"));
			employee.setEmail(rs.getString("Email"));
			employee.setMobileNo(rs.getString("MobileNo"));
			employee.setDateOfJoin(rs.getDate("DateOfJoin"));
			employee.setPosition(rs.getString("Position"));
			employee.setLeaveAvail(rs.getInt("EmpId"));
		}
		// TODO Auto-generated method stub
		return employee;
	}

	@Override
	public String addEmployDao(Employee employ) throws ClassNotFoundException, SQLException {
		if (employ.getLeaveAvail() < 0 || employ.getLeaveAvail() > 9) {
	        return "Invalid LeaveAvail value. Please enter a single-digit number (0-9).";
	    }
	    String cmd = "INSERT INTO Employee (FirstName, LastName, Gender, Dob, MaritalStatus, City, State, Email, MobileNo, DateOfJoin, Position, LeaveAvail) "
	            + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	    connection = ConnectionHelper.getConnection();
	    pst = connection.prepareStatement(cmd);
	    pst.setString(1, employ.getFirstName());
	    pst.setString(2, employ.getLastName());
	    pst.setString(3, employ.getGender().toString());
	    pst.setDate(4, employ.getDob());
	    pst.setString(5, employ.getMaritalStatus().toString());
	    pst.setString(6, employ.getCity());
	    pst.setString(7, employ.getState());
	    pst.setString(8, employ.getEmail());
	    pst.setString(9, employ.getMobileNo());
	    pst.setDate(10, employ.getDateOfJoin());
	    pst.setString(11, employ.getPosition());
	    pst.setInt(12, employ.getLeaveAvail());

	    int result = pst.executeUpdate();
	    if (result > 0) {
	        return "Employee added successfully!";
	    } else {
	        return "Failed to add employee.";
	    }
	}

	

	@Override
	public List<Employee> searchByName(String fullName) throws SQLException, ClassNotFoundException {
	    connection = ConnectionHelper.getConnection();
	    String query = "SELECT * FROM Employee WHERE firstName=?";
	    PreparedStatement stmt = connection.prepareStatement(query);
	    stmt.setString(1, fullName);
	   // stmt.setString(2, lastName);
	    ResultSet rs = stmt.executeQuery();
	    List<Employee> employees = new ArrayList<>();
	    while (rs.next()) {
	        Employee emp = new Employee();
	        emp.setEmpId(rs.getInt("EmpId"));
	        emp.setFirstName(rs.getString("FirstName"));
	        emp.setLastName(rs.getString("LastName"));
	        emp.setGender(Gender.valueOf(rs.getString("Gender").toUpperCase()));
	        emp.setDob(rs.getDate("Dob"));
	        emp.setMaritalStatus(Maritalstatus.valueOf(rs.getString("MaritalStatus").toUpperCase()));
	        emp.setCity(rs.getString("City"));
	        emp.setState(rs.getString("State"));
	        emp.setEmail(rs.getString("Email"));
	        emp.setMobileNo(rs.getString("MobileNo"));
	        emp.setDateOfJoin(rs.getDate("DateOfJoin"));
	        emp.setPosition(rs.getString("Position"));
	        emp.setLeaveAvail(rs.getInt("LeaveAvail"));
	        employees.add(emp);
	    }
	    return employees;
	}
	}
	
