package com.java.Casestudy.Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import com.java.Casestudy.model.Employee;
import com.java.Casestudy.model.Payroll;
import com.java.Casestudy.util.ConnectionHelper;

public class ParollDaoImpl implements ParollDao{

	@Override
	public void addPayRoll(Payroll payroll) throws ClassNotFoundException, SQLException {
	    String query = "INSERT INTO Payroll (EmpId, SalaryDate, Salary, Hra, Da, Ta, Tax, Pf) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
	    try (Connection conn = ConnectionHelper.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(query)) {
	        pstmt.setInt(1, payroll.getEmpId());
	        pstmt.setDate(2, payroll.getSalaryDate());
	        pstmt.setDouble(3, payroll.getSalary());
	        pstmt.setDouble(4, payroll.getHra());
	        pstmt.setDouble(5, payroll.getDa());
	        pstmt.setDouble(6, payroll.getTa());
	        pstmt.setDouble(7, payroll.getTax());
	        pstmt.setDouble(8, payroll.getPf());
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        System.err.println("Error occurred while inserting payroll: " + e.getMessage());
	        throw e;
	    }
	}



	@Override
	public Payroll getPayrollByEmpIdAndSalDate(int employeeId, LocalDate salDate) throws SQLException, ClassNotFoundException {
	    String query = "SELECT p.PayrollId, p.EmpId, p.SalaryDate, p.Salary, p.Hra, p.Da, p.Ta, p.Tax, p.Pf, " +
	                   "e.FirstName, e.LastName, e.Email " +
	                   "FROM Payroll p " +
	                   "JOIN Employee e ON p.EmpId = e.EmpId " +
	                   "WHERE p.EmpId = ? AND p.SalaryDate = ?";

	    try (Connection conn = ConnectionHelper.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(query)) {
	        pstmt.setInt(1, employeeId);  
	        pstmt.setDate(2, java.sql.Date.valueOf(salDate)); 
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            Payroll payroll = new Payroll();
	            payroll.setPayrollId(rs.getInt("PayrollId"));
	            payroll.setEmpId(rs.getInt("EmpId"));
	            payroll.setSalaryDate(rs.getDate("SalaryDate"));  
	            payroll.setSalary(rs.getDouble("Salary"));
	            payroll.setHra(rs.getDouble("Hra"));
	            payroll.setDa(rs.getDouble("Da"));
	            payroll.setTa(rs.getDouble("Ta"));
	            payroll.setTax(rs.getDouble("Tax"));
	            payroll.setPf(rs.getDouble("Pf"));
	            Employee employee = new Employee();
	            employee.setFirstName(rs.getString("FirstName"));
	            employee.setLastName(rs.getString("LastName"));
	            employee.setEmail(rs.getString("Email"));
	            payroll.setEmployee(employee);  

	            return payroll;
	        } else {
	            return null;  
	        }
	    } catch (SQLException e) {
	        System.err.println("Error occurred while fetching payroll and employee details: " + e.getMessage());
	        throw e;
	    }
	}



	
}
