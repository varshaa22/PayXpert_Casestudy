package com.java.Casestudy.Dao;

import java.sql.SQLException;

import com.java.Casestudy.model.Employee;
import com.java.Casestudy.model.LeaveDetails;

public interface LeaveDetailsDao {
	 void applyLeave(LeaveDetails leaveDetails) throws ClassNotFoundException, SQLException;
	 LeaveDetails searchLeaveById(int leaveId) throws SQLException, ClassNotFoundException;
	 Employee getEmployeeByLeaveId(int leaveId) throws SQLException, ClassNotFoundException;
}
