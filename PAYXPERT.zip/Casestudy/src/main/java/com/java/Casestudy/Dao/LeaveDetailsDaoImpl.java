package com.java.Casestudy.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.Casestudy.model.Employee;
import com.java.Casestudy.model.LeaveDetails;
import com.java.Casestudy.util.ConnectionHelper;

public class LeaveDetailsDaoImpl implements LeaveDetailsDao {

	@Override
	public void applyLeave(LeaveDetails leaveDetails) throws ClassNotFoundException, SQLException {
		String query = "INSERT INTO LeaveDetails (EmpId, LeaveStartDate, LeaveEndDate, Lop) VALUES (?, ?, ?, ?)";

        try (Connection conn = ConnectionHelper.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, leaveDetails.getEmpId());
            pstmt.setDate(2, leaveDetails.getLeaveStartDate());
            pstmt.setDate(3, leaveDetails.getLeaveEndDate());
            pstmt.setDouble(4, leaveDetails.getLop());
            pstmt.executeUpdate();

        } catch (SQLException e) {
            System.err.println("Error occurred while inserting leave details: " + e.getMessage());
            throw e;
        }
    }

	@Override
	public LeaveDetails searchLeaveById(int leaveId) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		LeaveDetails leaveDetail = null;
        String query = "SELECT * FROM LeaveDetails WHERE LeaveId = ?";
        
        try (Connection conn = ConnectionHelper.getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, leaveId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                leaveDetail = new LeaveDetails();
                leaveDetail.setLeaveId(rs.getInt("LeaveId"));
                leaveDetail.setEmpId(rs.getInt("EmpId"));
                leaveDetail.setLeaveStartDate(rs.getDate("LeaveStartDate"));
                leaveDetail.setLeaveEndDate(rs.getDate("LeaveEndDate"));
                leaveDetail.setLop(rs.getDouble("Lop"));
            }
        }
		return leaveDetail;
		
	}

	
	@Override
	public Employee getEmployeeByLeaveId(int leaveId) throws SQLException, ClassNotFoundException {
	    String query = "SELECT * FROM Employee WHERE EmpId = (SELECT EmpId FROM leavedetails WHERE LeaveID = ?)";
	    try (Connection conn = ConnectionHelper.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(query)) {
	        pstmt.setInt(1, leaveId); 
	        ResultSet rs = pstmt.executeQuery();   
	        if (rs.next()) {
	            int employeeId = rs.getInt("EmpId");
	            String firstName = rs.getString("FirstName");
	            String lastName = rs.getString("LastName");
	            String email = rs.getString("Email");
	            
	            // Create and return Employee object
	            Employee employee = new Employee();
	            employee.setEmpId(employeeId);
	            employee.setFirstName(firstName);
	            employee.setLastName(lastName);
	            employee.setEmail(email);
	            return employee; 
	        } else {
	            return null; 
	        }
	    } catch (SQLException e) {
	        System.err.println("Error occurred while fetching employee data: " + e.getMessage());
	        throw e;
	    }
	}
	
	
}
