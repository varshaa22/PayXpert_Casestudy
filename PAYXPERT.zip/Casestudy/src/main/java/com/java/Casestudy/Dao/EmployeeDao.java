package com.java.Casestudy.Dao;

import java.sql.SQLException;
import java.util.List;

import com.java.Casestudy.model.Employee;

public interface EmployeeDao {
	List<Employee> showEmployDao()throws SQLException,ClassNotFoundException;
	Employee searchByEmpId(int empId)throws SQLException,ClassNotFoundException;
	String addEmployDao(Employee employ)throws SQLException,ClassNotFoundException;	
	List<Employee> searchByName(String fullName) throws ClassNotFoundException, SQLException;
}
