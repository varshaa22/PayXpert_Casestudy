package com.java.Casestudy.model;

public enum Maritalstatus {
	SINGLE,MARRIED,OTHER
}
