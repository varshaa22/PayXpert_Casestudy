package com.java.Casestudy.model;

import java.sql.Date;

public class Employee {
	private int EmpId; 
    private String FirstName; 
    private String LastName; 
    private Gender Gender; 
    private Date Dob; 
    private Maritalstatus MaritalStatus; 
    private String City;
    private String State; 
    private String Email; 
    private String MobileNo;     
    private Date DateOfJoin; 
    private String Position;
    private int LeaveAvail;
	public int getEmpId() {
		return EmpId;
	}
	public void setEmpId(int empId) {
		EmpId = empId;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public Gender getGender() {
		return Gender;
	}
	public void setGender(Gender gender) {
		Gender = gender;
	}
	public Date getDob() {
		return Dob;
	}
	public void setDob(Date dob) {
		Dob = dob;
	}
	public Maritalstatus getMaritalStatus() {
		return MaritalStatus;
	}
	public void setMaritalStatus(Maritalstatus maritalStatus) {
		MaritalStatus = maritalStatus;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(String mobileNo) {
		MobileNo = mobileNo;
	}
	public Date getDateOfJoin() {
		return DateOfJoin;
	}
	public void setDateOfJoin(Date dateOfJoin) {
		DateOfJoin = dateOfJoin;
	}
	public String getPosition() {
		return Position;
	}
	public void setPosition(String position) {
		Position = position;
	}
	public int getLeaveAvail() {
		return LeaveAvail;
	}
	public void setLeaveAvail(int leaveAvail) {
		LeaveAvail = leaveAvail;
	}
	
	public Employee(int empId, String firstName, String lastName, String position) {
        this.EmpId = empId;
        this.FirstName = firstName;
        this.LastName = lastName;
        this.Position = position;
    }

	@Override
	public String toString() {
		return "Employee [EmpId=" + EmpId + ", FirstName=" + FirstName + ", LastName=" + LastName + ", Gender=" + Gender
				+ ", Dob=" + Dob + ", MaritalStatus=" + MaritalStatus + ", City=" + City + ", State=" + State
				+ ", Email=" + Email + ", MobileNo=" + MobileNo + ", DateOfJoin=" + DateOfJoin + ", Position="
				+ Position + ", LeaveAvail=" + LeaveAvail + "]";
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int empId, String firstName, String lastName, com.java.Casestudy.model.Gender gender, Date dob,
			Maritalstatus maritalStatus, String city, String state, String email, String mobileNo, Date dateOfJoin,
			String position, int leaveAvail) {
		super();
		EmpId = empId;
		FirstName = firstName;
		LastName = lastName;
		Gender = gender;
		Dob = dob;
		MaritalStatus = maritalStatus;
		City = city;
		State = state;
		Email = email;
		MobileNo = mobileNo;
		DateOfJoin = dateOfJoin;
		Position = position;
		LeaveAvail = leaveAvail;
	}
	public void setMobileNo(int int1) {
		// TODO Auto-generated method stub
		
	}
    
}
