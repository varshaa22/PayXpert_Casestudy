package com.java.Casestudy.model;

import java.sql.Date;

public class Payroll {
	private int PayrollId;
    private int EmpId;  
    private Date SalaryDate; 
    private double Salary; 
    private double Hra; 
    private double Da; 
    private double Ta; 
    private double Tax;
    private double Pf;
	public int getPayrollId() {
		return PayrollId;
	}
	public void setPayrollId(int payrollId) {
		PayrollId = payrollId;
	}
	public int getEmpId() {
		return EmpId;
	}
	public void setEmpId(int empId) {
		EmpId = empId;
	}
	public Date getSalaryDate() {
		return SalaryDate;
	}
	public void setSalaryDate(Date salaryDate) {
		SalaryDate = salaryDate;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		Salary = salary;
	}
	public double getHra() {
		return Hra;
	}
	public void setHra(double hra) {
		Hra = hra;
	}
	public double getDa() {
		return Da;
	}
	public void setDa(double da) {
		Da = da;
	}
	public double getTa() {
		return Ta;
	}
	public void setTa(double ta) {
		Ta = ta;
	}
	public double getTax() {
		return Tax;
	}
	public void setTax(double tax) {
		Tax = tax;
	}
	public double getPf() {
		return Pf;
	}
	public void setPf(double pf) {
		Pf = pf;
	}
	@Override
	public String toString() {
		return "Payroll [PayrollId=" + PayrollId + ", EmpId=" + EmpId + ", SalaryDate=" + SalaryDate + ", Salary="
				+ Salary + ", Hra=" + Hra + ", Da=" + Da + ", Ta=" + Ta + ", Tax=" + Tax + ", Pf=" + Pf + "]";
	}
	public Payroll() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Payroll(int payrollId, int empId, Date salaryDate, double salary, double hra, double da, double ta,
			double tax, double pf) {
		super();
		PayrollId = payrollId;
		EmpId = empId;
		SalaryDate = salaryDate;
		Salary = salary;
		Hra = hra;
		Da = da;
		Ta = ta;
		Tax = tax;
		Pf = pf;
	}
    

private Employee employee;  
public Employee getEmployee() {
    return employee;
}

public void setEmployee(Employee employee) {
    this.employee = employee;  
}
}
	