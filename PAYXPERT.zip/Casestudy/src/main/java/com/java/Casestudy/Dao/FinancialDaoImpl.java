package com.java.Casestudy.Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.java.Casestudy.model.Employee;
import com.java.Casestudy.model.Financial;
import com.java.Casestudy.model.RecordType;
import com.java.Casestudy.util.ConnectionHelper;

public class FinancialDaoImpl implements FinancialDao{

	@Override
	public boolean addFinancialRecord(Financial financial) throws ClassNotFoundException, SQLException {
        String cmd = "INSERT INTO Financial (EmpID, RecordDate, Description, Amount, RecordType) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = ConnectionHelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(cmd)) {

            setFinancialRecordParameters(pst, financial);

            int rowsInserted = pst.executeUpdate();
            return rowsInserted > 0;  
        }
    }
    private void setFinancialRecordParameters(PreparedStatement pst, Financial financial) throws SQLException {
        pst.setInt(1, financial.getEmployeeID());
        pst.setDate(2, financial.getRecordDate());
        pst.setString(3, financial.getDescription());
        pst.setDouble(4, financial.getAmount());
        pst.setString(5, financial.getRecordType().toString());
    }


	@Override

	public Financial infoByRecordId(int recordId) throws ClassNotFoundException, SQLException {
	    String cmd = "SELECT * FROM Financial WHERE RecordID = ?";
	    Financial financial = null;
	    try (Connection connection = ConnectionHelper.getConnection();
	         PreparedStatement pst = connection.prepareStatement(cmd)) {
	        pst.setInt(1, recordId);
	        try (ResultSet rs = pst.executeQuery()) {
	            if (rs.next()) {
	                financial = mapToFinancial(rs);  
	            }
	        }
	    }
	    return financial;
	}

	private Financial mapToFinancial(ResultSet rs) throws SQLException {
	    Financial financial = new Financial();
	    financial.setEmployeeID(rs.getInt("EmployeeID"));
	    financial.setRecordDate(rs.getDate("RecordDate"));
	    financial.setDescription(rs.getString("Description"));
	    financial.setAmount(rs.getDouble("Amount"));
	    String recordTypeStr = rs.getString("RecordType");
	    if (recordTypeStr != null) {
	        try {
	            financial.setRecordType(RecordType.valueOf(recordTypeStr));
	        } catch (IllegalArgumentException e) {
	            System.out.println("Invalid RecordType value in database: " + recordTypeStr);
	            financial.setRecordType(RecordType.INCOME); 
	        }
	    }

	    return financial;
	}

		
	@Override
	public List<Financial> getAllEmployeeFinacialRecord() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		String cmd = "SELECT * FROM Financial";
        List<Financial> financialRecords = new ArrayList<>();

        try (Connection connection = ConnectionHelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(cmd);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                financialRecords.add(mapToFinancial(rs));
            }
        }
        return financialRecords;
    }

		

	@Override
	public List<Financial> getLastThreeMonthsPaySlips(int employeeId) throws ClassNotFoundException, SQLException {
		String cmd = "SELECT * FROM Financial WHERE EmployeeID = ? AND RecordDate >= ?";
	    List<Financial> payslips = new ArrayList<>();
	    LocalDate threeMonthsAgo = LocalDate.now().minusMonths(3);	    
	    try (Connection connection = ConnectionHelper.getConnection();
	         PreparedStatement pst = connection.prepareStatement(cmd)) {
	        pst.setInt(1, employeeId);
	        pst.setDate(2, Date.valueOf(threeMonthsAgo));
	        
	        try (ResultSet rs = pst.executeQuery()) {
	            while (rs.next()) {
	                Financial record = mapToFinancialRecord(rs);
	                payslips.add(record);
	            }
	        }
	    }
	    
	    return payslips;
	}

	private Financial mapToFinancialRecord(ResultSet rs) throws SQLException {
	    return new Financial(
	            rs.getInt("RecordID"),
	            rs.getInt("EmployeeID"),
	            rs.getDate("RecordDate"),
	            rs.getString("Description"),
	            rs.getDouble("Amount"),
	            RecordType.valueOf(rs.getString("RecordType")) // Handle invalid RecordType if necessary
	    );
	}

		

	@Override
	public List<Financial> employeeFinacialInfo(int employeeId) throws ClassNotFoundException, SQLException {
	    String cmd = "SELECT * FROM Financial WHERE EmployeeID = ?";
	    List<Financial> records = new ArrayList<>();

	    try (Connection connection = ConnectionHelper.getConnection();
	         PreparedStatement pst = connection.prepareStatement(cmd)) {

	        pst.setInt(1, employeeId);

	        try (ResultSet rs = pst.executeQuery()) {
	            while (rs.next()) {
	                records.add(mapToFinancial(rs)); // continue using this
	            }
	        }
	    }
	    return records;
	}
	
	
	@Override
	public List<Financial> getEmployeeFinancialHistory(int employeeId) throws SQLException, ClassNotFoundException {
	    List<Financial> history = new ArrayList<>();
	    String query = "SELECT * FROM financial WHERE EmployeeID = ?"; 
	    try (Connection connection = ConnectionHelper.getConnection();
	         PreparedStatement stmt = connection.prepareStatement(query)) {
	        stmt.setInt(1, employeeId);
	        try (ResultSet rs = stmt.executeQuery()) {
	            while (rs.next()) {
	                history.add(mapToFinancialHistoryRecord(rs)); 
	            }
	        }
	    } catch (SQLException | ClassNotFoundException e) {
	        throw new SQLException("Error fetching financial history for EmployeeID: " + employeeId, e);
	    }
	    return history;
	}
	
	private Financial mapToFinancialHistoryRecord(ResultSet rs) throws SQLException {
	    String recordTypeStr = rs.getString("RecordType");
	    RecordType recordType = null;

	    if (recordTypeStr != null) {
	        try {
	            recordType = RecordType.valueOf(recordTypeStr.toUpperCase()); // Fix case mismatch
	        } catch (IllegalArgumentException e) {
	            System.out.println("Invalid RecordType: " + recordTypeStr);
	        }
	    }
	    return new Financial(
	            rs.getInt("RecordID"),
	            rs.getInt("EmployeeID"),
	            rs.getDate("RecordDate"),
	            rs.getString("Description"),
	            rs.getDouble("Amount"),
	            recordType 
	    );
	}
	@Override
	public List<Employee> getEmployeesWithoutPayroll() throws SQLException, ClassNotFoundException {
		String query = "SELECT * FROM employee e INNER JOIN financial f ON e.EmpId = f.EmployeeID";
	    List<Employee> employeesWithoutPayroll = new ArrayList<>();
	    try (Connection connection = ConnectionHelper.getConnection();
	         PreparedStatement pst = connection.prepareStatement(query);
	         ResultSet rs = pst.executeQuery()) {
	        while (rs.next()) {
	            Employee employee = new Employee(
	                    rs.getInt("empid"),          
	                    rs.getString("firstname"),   
	                    rs.getString("lastname"),     
	                    rs.getString("position")       
	            );
	            employeesWithoutPayroll.add(employee);
	        }
	    } catch (SQLException e) {
	        System.err.println("Error occurred while fetching employees without payroll: " + e.getMessage());
	        e.printStackTrace();
	    }
	    return employeesWithoutPayroll;
	}
	



}
