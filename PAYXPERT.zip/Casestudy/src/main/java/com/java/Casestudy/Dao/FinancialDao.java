package com.java.Casestudy.Dao;

import java.sql.SQLException;
import java.util.List;

import com.java.Casestudy.model.Employee;
import com.java.Casestudy.model.Financial;

public interface FinancialDao {
	Financial infoByRecordId(int recordId) throws ClassNotFoundException, SQLException;
	List<Financial> getAllEmployeeFinacialRecord() throws ClassNotFoundException, SQLException;
	List<Financial> getLastThreeMonthsPaySlips(int employeeId) throws ClassNotFoundException, SQLException;
	List<Financial> employeeFinacialInfo(int employeeId) throws ClassNotFoundException, SQLException;
	boolean addFinancialRecord(Financial financial) throws ClassNotFoundException, SQLException;
	List<Financial> getEmployeeFinancialHistory(int employeeId) throws SQLException, ClassNotFoundException;
	List<Employee> getEmployeesWithoutPayroll() throws SQLException, ClassNotFoundException;

}
